## Meta info

- Is this a bug or suggestion?:
- Version (click on help icon in footer):
- Context - Web app, Chrome extension or both?:

<!-- Describe your issue here -->
