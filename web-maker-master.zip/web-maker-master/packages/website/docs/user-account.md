---
title: 'User account'
---

You can login with your favourite social account to create a user account inside Web Maker and save all your creations in the cloud. That way no matter on which computer you are, you can open Web Maker, login with your account and get back all your creations to continue work on them!

When you are not logged in, you can still save creations. These get stored in the Local Storage of your browser and are available only on that computer and that browser. Once you login, you don't see your locally saved creations. But worry not, they don't get deleted. You can logout and access them again. You also get an option to import all your local creations to your account once you login - it's highly recommended you do that.
