---
title: 'Introduction'
---

**Web-Maker** is a blazing fast & offline frontend playground for your web experiments. Its available as a Chrome extension and a web app as well. Both are offline usable!

![Screenshot](/images/ss1.png)
