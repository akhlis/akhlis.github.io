---
title: 'Pre-processors'
---

Web Maker supports bunch of pre-processors in for HTML, CSS & JavaScript each. You can switch to any for your current creation by click on each pane's title.

<video src="./images/switching-preprocessor.mp4" loop autoplay></video>
