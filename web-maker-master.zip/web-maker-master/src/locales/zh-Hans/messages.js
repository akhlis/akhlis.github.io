/* eslint-disable */ export default {
	languageData: {
		plurals: function(n, ord) {
			if (ord) return 'other';
			return 'other';
		}
	},
	messages: {
		'Add a JS/CSS library': 'Add a JS/CSS library',
		'Add library': 'Add library',
		Console: 'Console',
		Login: 'Login',
		New: 'New',
		Open: 'Open',
		Run: 'Run',
		Save: 'Save',
		Signup: 'Signup'
	}
};
